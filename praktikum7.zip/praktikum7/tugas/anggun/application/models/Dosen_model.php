<?php

// class
class Dosen_model extends CI_Model{
     // struktur data
     public $id, $nama, $nidn, $gender, $tmp_lahir, $tgl_lahir, $pendidikan;
}
?>