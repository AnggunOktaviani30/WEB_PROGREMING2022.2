<?php

// class
class Mahasiswa_model extends CI_Model{
     // struktur data
     public $id, $nama, $nim, $gender, $tmp_lahir, $tgl_lahir, $ipk;
     // method
     public function predikat(){
          // kondisi
          $predikat = ($this->ipk >= 3.75) ? "Cumlaude" : "Baik";
          return $predikat;
     } 
}
?>