<?php

// class
class Matakuliah_model extends CI_Model{
     // struktur data
     public $id, $nama, $kode;
    
}

?>