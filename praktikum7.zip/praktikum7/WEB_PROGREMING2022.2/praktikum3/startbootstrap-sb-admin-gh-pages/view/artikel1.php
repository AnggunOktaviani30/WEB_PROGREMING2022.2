<?php
include '../layout/header.php';
?>

<h1 align="center" Welcome To Website</h1>
    <hr>
    <br>
    <br>
    <br>
    <h>Kampus IT yang Siap Menjadi Perintis Teknologi Digital Masa Depan</h>
    <h3>STT Terpadu Nurul Fikri Mencetak Sarjana Komputer yang Berakhlak Mulia, Professional dan Bersertifikat IT serta Mampu Bersaing Secara Global.<h3>
    <h3>Sejarah Perjalanan Berdirinya Sekolah Tinggi Teknologi Terpadu Nurul Fikri<?h3>
    <h3>Sekolah Tinggi Teknologi Terpadu Nurul Fikri (populer disebut STT-NF) merupakan perguruan tinggi yang memadukan keilmuan praktis di bidang teknologi informasi dengan pengembangan kepribadian islami, kompeten dan berkarakter. Pada tahun 2012, STT-NF resmi berdiri berdasarkan SK Menteri Pendidikan dan Kebudayaan Nomor 269/E/O/2012.</h3>
    <br>
    <br>
    <br>
    
    <br>
    <hr>
    <br>
    <hr>


<?php
include "../layout/footer.php";
?>