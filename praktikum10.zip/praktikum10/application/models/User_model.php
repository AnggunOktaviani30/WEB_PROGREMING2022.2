<?php 
 class User_model extends CI_Model{

     private $table = 'user';
     
     public function getAll(){
        
         $query = $this->db->get($this->table);
         return $query->result();
     }

     public function findById($id){
         $this->db->where('id',$id);
         $query = $this->db->get($this->table);
         return $query->row();
     }

     public function login($_username,$_password){
        $sql = "SELECT* FROM `user` WHERE username = '$_username'and password = '$_password'";
         $data = [$_username,$_password];
         $query = $this->db->query($sql, $data);
         return $query->row();
     }

     function cek_login($table,$where){		
		return $this->db->get_where($table,$where);
	}	

}
?>